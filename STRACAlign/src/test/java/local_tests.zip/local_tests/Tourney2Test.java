package local_tests;

import org.junit.Test;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class Tourney2Test extends TestAligners {


    @Test
    public void _youtube_com_youtube_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "youtube_com_youtube_com";



        testAlign(testPair, 0,
                "youtube.com.75.bytecode.txt",
                "youtube.com.88.bytecode.txt");




        testAlign(testPair, 0,
                "youtube.com.31.bytecode.txt",
                "youtube.com.27.bytecode.txt");




        testAlign(testPair, 0,
                "youtube.com.27.bytecode.txt",
                "youtube.com.50.bytecode.txt");




        testAlign(testPair, 0,
                "youtube.com.29.bytecode.txt",
                "youtube.com.32.bytecode.txt");




        testAlign(testPair, 0,
                "youtube.com.69.bytecode.txt",
                "youtube.com.45.bytecode.txt");




        testAlign(testPair, 0,
                "youtube.com.60.bytecode.txt",
                "youtube.com.77.bytecode.txt");



    }

    @Test
    public void _2019_splashcon_org_2019_splashcon_org() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "2019_splashcon_org_2019_splashcon_org";



        testAlign(testPair, 0,
                "2019.splashcon.org.21.bytecode.txt",
                "2019.splashcon.org.5.bytecode.txt");




        testAlign(testPair, 0,
                "2019.splashcon.org.100.bytecode.txt",
                "2019.splashcon.org.4.bytecode.txt");




        testAlign(testPair, 0,
                "2019.splashcon.org.31.bytecode.txt",
                "2019.splashcon.org.37.bytecode.txt");




        testAlign(testPair, 0,
                "2019.splashcon.org.66.bytecode.txt",
                "2019.splashcon.org.65.bytecode.txt");




        testAlign(testPair, 0,
                "2019.splashcon.org.48.bytecode.txt",
                "2019.splashcon.org.82.bytecode.txt");




        testAlign(testPair, 0,
                "2019.splashcon.org.95.bytecode.txt",
                "2019.splashcon.org.80.bytecode.txt");



    }

    @Test
    public void _www_kth_se_www_kth_se() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "www_kth_se_www_kth_se";



        testAlign(testPair, 0,
                "www.kth.se.54.bytecode.txt",
                "www.kth.se.77.bytecode.txt");




        testAlign(testPair, 0,
                "www.kth.se.25.bytecode.txt",
                "www.kth.se.91.bytecode.txt");




        testAlign(testPair, 0,
                "www.kth.se.18.bytecode.txt",
                "www.kth.se.51.bytecode.txt");




        testAlign(testPair, 0,
                "www.kth.se.26.bytecode.txt",
                "www.kth.se.88.bytecode.txt");




        testAlign(testPair, 0,
                "www.kth.se.59.bytecode.txt",
                "www.kth.se.55.bytecode.txt");




        testAlign(testPair, 0,
                "www.kth.se.80.bytecode.txt",
                "www.kth.se.53.bytecode.txt");



    }

    @Test
    public void _www_github_com_www_github_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "www_github_com_www_github_com";



        testAlign(testPair, 0,
                "www.github.com.34.bytecode.txt",
                "www.github.com.73.bytecode.txt");




        testAlign(testPair, 0,
                "www.github.com.45.bytecode.txt",
                "www.github.com.61.bytecode.txt");




        testAlign(testPair, 0,
                "www.github.com.94.bytecode.txt",
                "www.github.com.31.bytecode.txt");




        testAlign(testPair, 0,
                "www.github.com.32.bytecode.txt",
                "www.github.com.21.bytecode.txt");




        testAlign(testPair, 0,
                "www.github.com.100.bytecode.txt",
                "www.github.com.39.bytecode.txt");




        testAlign(testPair, 0,
                "www.github.com.41.bytecode.txt",
                "www.github.com.2.bytecode.txt");



    }

    @Test
    public void _wikipedia_org_wikipedia_org() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "wikipedia_org_wikipedia_org";



        testAlign(testPair, 0,
                "wikipedia.org.86.bytecode.txt",
                "wikipedia.org.19.bytecode.txt");




        testAlign(testPair, 0,
                "wikipedia.org.92.bytecode.txt",
                "wikipedia.org.31.bytecode.txt");




        testAlign(testPair, 0,
                "wikipedia.org.80.bytecode.txt",
                "wikipedia.org.62.bytecode.txt");




        testAlign(testPair, 0,
                "wikipedia.org.94.bytecode.txt",
                "wikipedia.org.15.bytecode.txt");




        testAlign(testPair, 0,
                "wikipedia.org.45.bytecode.txt",
                "wikipedia.org.33.bytecode.txt");




        testAlign(testPair, 0,
                "wikipedia.org.29.bytecode.txt",
                "wikipedia.org.15.bytecode.txt");



    }

    @Test
    public void _www_google_com_www_google_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "www_google_com_www_google_com";



        testAlign(testPair, 0,
                "www.google.com.8.bytecode.txt",
                "www.google.com.95.bytecode.txt");




        testAlign(testPair, 0,
                "www.google.com.72.bytecode.txt",
                "www.google.com.61.bytecode.txt");




        testAlign(testPair, 0,
                "www.google.com.18.bytecode.txt",
                "www.google.com.51.bytecode.txt");




        testAlign(testPair, 0,
                "www.google.com.66.bytecode.txt",
                "www.google.com.26.bytecode.txt");




        testAlign(testPair, 0,
                "www.google.com.19.bytecode.txt",
                "www.google.com.91.bytecode.txt");




        testAlign(testPair, 0,
                "www.google.com.36.bytecode.txt",
                "www.google.com.88.bytecode.txt");



    }


}
