package local_tests;

import org.junit.Test;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class TourneyTest extends TestAligners {



    @Test
    public void _youtube_com_youtube_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "youtube_com_youtube_com";



        testAlign(testPair, 0,
                "youtube.com.93.bytecode.txt",
                "youtube.com.52.bytecode.txt");




        testAlign(testPair, 0,
                "youtube.com.96.bytecode.txt",
                "youtube.com.96.bytecode.txt");




        testAlign(testPair, 0,
                "youtube.com.6.bytecode.txt",
                "youtube.com.11.bytecode.txt");




        testAlign(testPair, 0,
                "youtube.com.31.bytecode.txt",
                "youtube.com.68.bytecode.txt");




        testAlign(testPair, 0,
                "youtube.com.96.bytecode.txt",
                "youtube.com.23.bytecode.txt");




        testAlign(testPair, 0,
                "youtube.com.62.bytecode.txt",
                "youtube.com.13.bytecode.txt");



    }

    @Test
    public void _youtube_com_2019_splashcon_org() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "youtube_com_2019_splashcon_org";



        testAlign(testPair, 1,
                "youtube.com.81.bytecode.txt",
                "2019.splashcon.org.70.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.12.bytecode.txt",
                "2019.splashcon.org.37.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.84.bytecode.txt",
                "2019.splashcon.org.46.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.83.bytecode.txt",
                "2019.splashcon.org.65.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.11.bytecode.txt",
                "2019.splashcon.org.86.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.100.bytecode.txt",
                "2019.splashcon.org.20.bytecode.txt");



    }

    @Test
    public void _youtube_com_www_kth_se() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "youtube_com_www_kth_se";



        testAlign(testPair, 1,
                "youtube.com.54.bytecode.txt",
                "www.kth.se.59.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.86.bytecode.txt",
                "www.kth.se.29.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.93.bytecode.txt",
                "www.kth.se.10.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.83.bytecode.txt",
                "www.kth.se.54.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.49.bytecode.txt",
                "www.kth.se.67.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.85.bytecode.txt",
                "www.kth.se.89.bytecode.txt");



    }

    @Test
    public void _youtube_com_www_github_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "youtube_com_www_github_com";



        testAlign(testPair, 1,
                "youtube.com.45.bytecode.txt",
                "www.github.com.78.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.40.bytecode.txt",
                "www.github.com.58.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.41.bytecode.txt",
                "www.github.com.50.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.78.bytecode.txt",
                "www.github.com.76.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.62.bytecode.txt",
                "www.github.com.86.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.71.bytecode.txt",
                "www.github.com.22.bytecode.txt");



    }

    @Test
    public void _youtube_com_wikipedia_org() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "youtube_com_wikipedia_org";



        testAlign(testPair, 1,
                "youtube.com.14.bytecode.txt",
                "wikipedia.org.88.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.12.bytecode.txt",
                "wikipedia.org.27.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.51.bytecode.txt",
                "wikipedia.org.80.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.77.bytecode.txt",
                "wikipedia.org.61.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.57.bytecode.txt",
                "wikipedia.org.15.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.45.bytecode.txt",
                "wikipedia.org.93.bytecode.txt");



    }

    @Test
    public void _youtube_com_www_google_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "youtube_com_www_google_com";



        testAlign(testPair, 1,
                "youtube.com.20.bytecode.txt",
                "www.google.com.76.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.73.bytecode.txt",
                "www.google.com.53.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.48.bytecode.txt",
                "www.google.com.33.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.96.bytecode.txt",
                "www.google.com.57.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.11.bytecode.txt",
                "www.google.com.70.bytecode.txt");




        testAlign(testPair, 1,
                "youtube.com.43.bytecode.txt",
                "www.google.com.72.bytecode.txt");



    }

    @Test
    public void _2019_splashcon_org_2019_splashcon_org() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "2019_splashcon_org_2019_splashcon_org";



        testAlign(testPair, 0,
                "2019.splashcon.org.81.bytecode.txt",
                "2019.splashcon.org.10.bytecode.txt");




        testAlign(testPair, 0,
                "2019.splashcon.org.78.bytecode.txt",
                "2019.splashcon.org.89.bytecode.txt");




        testAlign(testPair, 0,
                "2019.splashcon.org.24.bytecode.txt",
                "2019.splashcon.org.41.bytecode.txt");




        testAlign(testPair, 0,
                "2019.splashcon.org.47.bytecode.txt",
                "2019.splashcon.org.46.bytecode.txt");




        testAlign(testPair, 0,
                "2019.splashcon.org.33.bytecode.txt",
                "2019.splashcon.org.89.bytecode.txt");




        testAlign(testPair, 0,
                "2019.splashcon.org.38.bytecode.txt",
                "2019.splashcon.org.54.bytecode.txt");



    }

    @Test
    public void _2019_splashcon_org_www_kth_se() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "2019_splashcon_org_www_kth_se";



        testAlign(testPair, 1,
                "2019.splashcon.org.65.bytecode.txt",
                "www.kth.se.3.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.1.bytecode.txt",
                "www.kth.se.31.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.29.bytecode.txt",
                "www.kth.se.42.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.55.bytecode.txt",
                "www.kth.se.59.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.74.bytecode.txt",
                "www.kth.se.3.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.44.bytecode.txt",
                "www.kth.se.63.bytecode.txt");



    }

    @Test
    public void _2019_splashcon_org_www_github_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "2019_splashcon_org_www_github_com";



        testAlign(testPair, 1,
                "2019.splashcon.org.65.bytecode.txt",
                "www.github.com.68.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.78.bytecode.txt",
                "www.github.com.72.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.8.bytecode.txt",
                "www.github.com.90.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.51.bytecode.txt",
                "www.github.com.41.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.70.bytecode.txt",
                "www.github.com.50.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.71.bytecode.txt",
                "www.github.com.50.bytecode.txt");



    }

    @Test
    public void _2019_splashcon_org_wikipedia_org() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "2019_splashcon_org_wikipedia_org";



        testAlign(testPair, 1,
                "2019.splashcon.org.44.bytecode.txt",
                "wikipedia.org.48.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.37.bytecode.txt",
                "wikipedia.org.83.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.78.bytecode.txt",
                "wikipedia.org.43.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.1.bytecode.txt",
                "wikipedia.org.61.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.26.bytecode.txt",
                "wikipedia.org.96.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.59.bytecode.txt",
                "wikipedia.org.46.bytecode.txt");



    }

    @Test
    public void _2019_splashcon_org_www_google_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "2019_splashcon_org_www_google_com";



        testAlign(testPair, 1,
                "2019.splashcon.org.62.bytecode.txt",
                "www.google.com.47.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.11.bytecode.txt",
                "www.google.com.18.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.18.bytecode.txt",
                "www.google.com.18.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.72.bytecode.txt",
                "www.google.com.50.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.21.bytecode.txt",
                "www.google.com.63.bytecode.txt");




        testAlign(testPair, 1,
                "2019.splashcon.org.74.bytecode.txt",
                "www.google.com.72.bytecode.txt");



    }

    @Test
    public void _www_kth_se_www_kth_se() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "www_kth_se_www_kth_se";



        testAlign(testPair, 0,
                "www.kth.se.58.bytecode.txt",
                "www.kth.se.78.bytecode.txt");




        testAlign(testPair, 0,
                "www.kth.se.94.bytecode.txt",
                "www.kth.se.80.bytecode.txt");




        testAlign(testPair, 0,
                "www.kth.se.35.bytecode.txt",
                "www.kth.se.65.bytecode.txt");




        testAlign(testPair, 0,
                "www.kth.se.32.bytecode.txt",
                "www.kth.se.88.bytecode.txt");




        testAlign(testPair, 0,
                "www.kth.se.49.bytecode.txt",
                "www.kth.se.19.bytecode.txt");




        testAlign(testPair, 0,
                "www.kth.se.67.bytecode.txt",
                "www.kth.se.4.bytecode.txt");



    }

    @Test
    public void _www_kth_se_www_github_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "www_kth_se_www_github_com";



        testAlign(testPair, 1,
                "www.kth.se.7.bytecode.txt",
                "www.github.com.66.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.4.bytecode.txt",
                "www.github.com.38.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.3.bytecode.txt",
                "www.github.com.61.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.38.bytecode.txt",
                "www.github.com.82.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.84.bytecode.txt",
                "www.github.com.56.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.35.bytecode.txt",
                "www.github.com.70.bytecode.txt");



    }

    @Test
    public void _www_kth_se_wikipedia_org() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "www_kth_se_wikipedia_org";



        testAlign(testPair, 1,
                "www.kth.se.48.bytecode.txt",
                "wikipedia.org.42.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.28.bytecode.txt",
                "wikipedia.org.63.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.69.bytecode.txt",
                "wikipedia.org.77.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.89.bytecode.txt",
                "wikipedia.org.75.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.95.bytecode.txt",
                "wikipedia.org.66.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.85.bytecode.txt",
                "wikipedia.org.32.bytecode.txt");



    }

    @Test
    public void _www_kth_se_www_google_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "www_kth_se_www_google_com";



        testAlign(testPair, 1,
                "www.kth.se.21.bytecode.txt",
                "www.google.com.91.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.69.bytecode.txt",
                "www.google.com.46.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.77.bytecode.txt",
                "www.google.com.71.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.5.bytecode.txt",
                "www.google.com.74.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.11.bytecode.txt",
                "www.google.com.71.bytecode.txt");




        testAlign(testPair, 1,
                "www.kth.se.44.bytecode.txt",
                "www.google.com.85.bytecode.txt");



    }

    @Test
    public void _www_github_com_www_github_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "www_github_com_www_github_com";



        testAlign(testPair, 0,
                "www.github.com.53.bytecode.txt",
                "www.github.com.52.bytecode.txt");




        testAlign(testPair, 0,
                "www.github.com.81.bytecode.txt",
                "www.github.com.71.bytecode.txt");




        testAlign(testPair, 0,
                "www.github.com.10.bytecode.txt",
                "www.github.com.72.bytecode.txt");




        testAlign(testPair, 0,
                "www.github.com.69.bytecode.txt",
                "www.github.com.39.bytecode.txt");




        testAlign(testPair, 0,
                "www.github.com.3.bytecode.txt",
                "www.github.com.67.bytecode.txt");




        testAlign(testPair, 0,
                "www.github.com.3.bytecode.txt",
                "www.github.com.3.bytecode.txt");



    }

    @Test
    public void _www_github_com_wikipedia_org() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "www_github_com_wikipedia_org";



        testAlign(testPair, 1,
                "www.github.com.5.bytecode.txt",
                "wikipedia.org.78.bytecode.txt");




        testAlign(testPair, 1,
                "www.github.com.82.bytecode.txt",
                "wikipedia.org.24.bytecode.txt");




        testAlign(testPair, 1,
                "www.github.com.40.bytecode.txt",
                "wikipedia.org.69.bytecode.txt");




        testAlign(testPair, 1,
                "www.github.com.17.bytecode.txt",
                "wikipedia.org.48.bytecode.txt");




        testAlign(testPair, 1,
                "www.github.com.41.bytecode.txt",
                "wikipedia.org.10.bytecode.txt");




        testAlign(testPair, 1,
                "www.github.com.38.bytecode.txt",
                "wikipedia.org.40.bytecode.txt");



    }

    @Test
    public void _www_github_com_www_google_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "www_github_com_www_google_com";



        testAlign(testPair, 1,
                "www.github.com.29.bytecode.txt",
                "www.google.com.86.bytecode.txt");




        testAlign(testPair, 1,
                "www.github.com.69.bytecode.txt",
                "www.google.com.41.bytecode.txt");




        testAlign(testPair, 1,
                "www.github.com.7.bytecode.txt",
                "www.google.com.58.bytecode.txt");




        testAlign(testPair, 1,
                "www.github.com.35.bytecode.txt",
                "www.google.com.87.bytecode.txt");




        testAlign(testPair, 1,
                "www.github.com.83.bytecode.txt",
                "www.google.com.79.bytecode.txt");




        testAlign(testPair, 1,
                "www.github.com.46.bytecode.txt",
                "www.google.com.13.bytecode.txt");



    }

    @Test
    public void _wikipedia_org_wikipedia_org() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "wikipedia_org_wikipedia_org";



        testAlign(testPair, 0,
                "wikipedia.org.8.bytecode.txt",
                "wikipedia.org.81.bytecode.txt");




        testAlign(testPair, 0,
                "wikipedia.org.32.bytecode.txt",
                "wikipedia.org.34.bytecode.txt");




        testAlign(testPair, 0,
                "wikipedia.org.64.bytecode.txt",
                "wikipedia.org.39.bytecode.txt");




        testAlign(testPair, 0,
                "wikipedia.org.24.bytecode.txt",
                "wikipedia.org.96.bytecode.txt");




        testAlign(testPair, 0,
                "wikipedia.org.79.bytecode.txt",
                "wikipedia.org.55.bytecode.txt");




        testAlign(testPair, 0,
                "wikipedia.org.28.bytecode.txt",
                "wikipedia.org.26.bytecode.txt");



    }

    @Test
    public void _wikipedia_org_www_google_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "wikipedia_org_www_google_com";



        testAlign(testPair, 1,
                "wikipedia.org.7.bytecode.txt",
                "www.google.com.36.bytecode.txt");




        testAlign(testPair, 1,
                "wikipedia.org.71.bytecode.txt",
                "www.google.com.100.bytecode.txt");




        testAlign(testPair, 1,
                "wikipedia.org.37.bytecode.txt",
                "www.google.com.27.bytecode.txt");




        testAlign(testPair, 1,
                "wikipedia.org.82.bytecode.txt",
                "www.google.com.34.bytecode.txt");




        testAlign(testPair, 1,
                "wikipedia.org.48.bytecode.txt",
                "www.google.com.15.bytecode.txt");




        testAlign(testPair, 1,
                "wikipedia.org.36.bytecode.txt",
                "www.google.com.4.bytecode.txt");



    }

    @Test
    public void _www_google_com_www_google_com() throws IOException , InstantiationException, IllegalAccessException, InvocationTargetException {
        String testPair = "www_google_com_www_google_com";



        testAlign(testPair, 0,
                "www.google.com.87.bytecode.txt",
                "www.google.com.6.bytecode.txt");




        testAlign(testPair, 0,
                "www.google.com.29.bytecode.txt",
                "www.google.com.56.bytecode.txt");




        testAlign(testPair, 0,
                "www.google.com.46.bytecode.txt",
                "www.google.com.82.bytecode.txt");




        testAlign(testPair, 0,
                "www.google.com.66.bytecode.txt",
                "www.google.com.51.bytecode.txt");




        testAlign(testPair, 0,
                "www.google.com.95.bytecode.txt",
                "www.google.com.20.bytecode.txt");




        testAlign(testPair, 0,
                "www.google.com.23.bytecode.txt",
                "www.google.com.18.bytecode.txt");



    }

}
