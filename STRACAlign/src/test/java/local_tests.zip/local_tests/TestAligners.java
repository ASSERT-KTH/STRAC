package local_tests;

import align.AlignDistance;
import core.LogProvider;
import core.ServiceRegister;
import interpreter.AlignInterpreter;
import interpreter.dto.Alignment;
import interpreter.dto.Payload;
import org.junit.Test;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;

public class TestAligners extends BaseResourceFileTest {

    public void testAlign(String name, int eq, String name1, String name2) throws InvocationTargetException, InstantiationException, IllegalAccessException, IOException {
        Alignment dto = new Alignment();
        dto.method = new Payload.MethodInfo();
        dto.method.name = "DTW";
        dto.method.params = Arrays.asList();
        //dto.distanceFunctionName = "dBin";
        dto.comparison = new Alignment.Comparison();
        dto.comparison.gap = 1;
        dto.comparison.diff = 5;
        dto.comparison.eq = 0;
        dto.pairs = new ArrayList<>();
        dto.outputAlignment = true;
        dto.separator ="[\n\r]";
        dto.clean =new String[] {
                "( )*\\d+ [ES]>",
                "0x\\w+ @",
                "\\w+ : ",
                " [A-Z](.*)"
        };
        //dto.include = new Alignment.Include();
        //dto.include.pattern = "^([0-9a-f]{2}) ([0-9a-f]{2} )*";
        //dto.include.group = 1;

        dto.outputDir="reports";
        //dto.exportImage = true;
        // 39111
        // 39384


        dto.files = Arrays.asList(
                name1,
                name2
        );

        AlignInterpreter interpreter = new AlignInterpreter(null);


        interpreter.execute(dto, null, this::getFile);


    }

    @Test
    public void testDTW() throws InvocationTargetException, InstantiationException, IllegalAccessException, IOException {
        Alignment dto = new Alignment();
        dto.method = new Payload.MethodInfo();
        dto.method.name = "DTW";
        dto.method.params = Arrays.asList();
        //dto.distanceFunctionName = "dBin";
        dto.comparison = new Alignment.Comparison();
        dto.comparison.gap = 1;
        dto.comparison.diff = 5;
        dto.comparison.eq = 0;
        dto.pairs = new ArrayList<>();
        dto.outputAlignment = true;
        dto.separator ="[\n\r]";
        dto.clean =new String[] {
                "( )*\\d+ [ES]>",
                "0x\\w+ @",
                "\\w+ : ",
                " [A-Z](.*)"
        };
        dto.outputDir="reports";
        //dto.exportImage = true;


        dto.files = Arrays.asList(
                "bytecodes/wikipedia.org.bytecode",
                "bytecodes/wikipedia.1.org.bytecode"
        );

        AlignInterpreter interpreter = new AlignInterpreter(null);


        interpreter.execute(dto, null, this::getFile);


    }


    @Test
    public void testDTW1() throws InvocationTargetException, InstantiationException, IllegalAccessException, IOException {
        testAlign("ww",0,
                "bytecodes/wikipedia.org.bytecode",
                "bytecodes/wikipedia.1.org.bytecode");
    }



    @Test
    public void testDTW2() throws InvocationTargetException, InstantiationException, IllegalAccessException, IOException {
        testAlign("ws",1,
                "bytecodes/wikipedia.org.bytecode",
                "bytecodes/2019.splashcoon.org.bytecode");
    }


    @Test
    public void testDTW3() throws InvocationTargetException, InstantiationException, IllegalAccessException, IOException {
        testAlign("google_github",1,
                "bytecodes/www.google.com.bytecode",
                "bytecodes/www.github.com.bytecode");
    }

}
